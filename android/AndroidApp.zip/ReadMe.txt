1. 'app-debug.apk' is working on all of the emulators and most of the devices tested.
2. Transfer it to your preferred Android Device, and install.
	(You'll need to enable third-party APK installation from your device's settings.)
	(Refer: 1. https://www.androidauthority.com/how-to-install-apks-31494/)
	(Refer: 2. https://www.expressvpn.com/support/vpn-setup/enable-apk-installs-android/)
3. Install and use it.
4. For testing, you may use the following given account, Or press 'register' and create an account for yourself by pressing 'Don't have an account yet? Signup here.' Enter all relevant details, Press back.

Username		virginia
Password		connectingwatest



Made By,
Shriraj Pethe
Imran Shaikh

For our MCA Final Year Project.
